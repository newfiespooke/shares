# Archived
**This repo is now archived in favor of the [BL3 Save Editor](https://github.com/FromDarkHell/BL3SaveEditor) by yours truly.**

<hr>

## Borderlands 3 Profile Editor
 
A slightly wonky program created so that way *you!* can edit your profile.sav file for Borderlands 3.

# Installation
1. Download the exe available at [Releases](https://github.com/FromDarkHell/BL3ProfileEditor/releases)
2. Run the exe
3. Click `Open` and select your `profile.sav`.
4. Edit your profile to your hearts content
5. Whenever you're done editing, click `Save` to save your profile. Don't worry, it'll create a backup in case you wanna go back.

# Credits
* [Gibbed](https://github.com/Gibbed) for helping extract the protobufs from the initial exes, as well as figuring out the encryption/decryption of the profiles.
* [Apocalyptech](https://github.com/apocalyptech/) for creating the [google sheet](https://docs.google.com/spreadsheets/d/1v-F_3C2ceaFKJae1b6wmbelw_jLjmPPriBLzGTZMqRc/edit?usp=sharing) that I use to create a list of cosmetics for unlocking.
* [BrokenNoah](https://www.deviantart.com/brokennoah) for creating the cool free icons for [Borderlands 3](https://www.deviantart.com/brokennoah/art/Borderlands-3-icons-797030087)
* [Gearbox Software](https://www.gearboxsoftware.com/) obviously for creating BL3
